package com.example.mpodev4;

public class Gorsel {
    String bilgi;
    int siraNo;
    int foto;

    public Gorsel(String bilgi,int siraNo,int foto){
        this.bilgi=bilgi;
        this.siraNo=siraNo;
        this.foto=foto;
    }

}
